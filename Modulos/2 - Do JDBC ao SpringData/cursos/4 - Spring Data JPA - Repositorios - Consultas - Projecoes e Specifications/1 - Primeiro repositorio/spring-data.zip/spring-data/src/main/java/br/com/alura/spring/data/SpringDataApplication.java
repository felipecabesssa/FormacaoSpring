package br.com.alura.spring.data;

import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import br.com.alura.spring.data.orm.Cargo;
import br.com.alura.spring.data.repository.CargoRepository;

@SpringBootApplication
public class SpringDataApplication implements CommandLineRunner {

	private final CargoRepository repository;
	
	public SpringDataApplication(CargoRepository repository) {
		this.repository = repository;
	}
	
	public static void main(String[] args) {
		SpringApplication.run(SpringDataApplication.class, args);
	}

	@Override
	public void run(String... args) throws Exception {
		
		Cargo cargo = new Cargo();
		cargo.setDescricao("DESENVOLVEDOR DE SOFTWARE");		
		repository.save(cargo);
		
		Cargo cargo1 = new Cargo();
		cargo1.setDescricao("ANALISTA DE TESTES");		
		repository.save(cargo1);
		
		Cargo cargo2 = new Cargo();
		cargo2.setDescricao("GERENTE DE PRODUCAO");		
		repository.save(cargo2);
		
		Cargo cargo3 = new Cargo();
		cargo3.setDescricao("ESTAGIARIO");		
		repository.save(cargo3);
		
		Cargo cargo4 = new Cargo();
		cargo4.setDescricao("DIRETOR");		
		repository.save(cargo4);
		
	}

}
